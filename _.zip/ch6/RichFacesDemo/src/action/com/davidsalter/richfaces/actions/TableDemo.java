package com.davidsalter.richfaces.actions;

/**
 * Sample source code for Chapter 6 of "Developing Seam 2.x Web Applications"
 * See http://www.packtpub.com/seam-2-x-web-development/book
 * 
 * @author david
 * @version 1.0
 *
 */
public interface TableDemo {

    public void countryList();
    public void remove();

}
