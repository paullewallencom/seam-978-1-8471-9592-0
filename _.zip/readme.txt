Sample Code Read Me
-------------------

Sample code has been provides for the many examples throughout the book.

So as to not make the sample code download very large, the Seam runtime has
been excluded from all of the SeamGen example programs. Before building these
applications, the lib and bootstrap directories need to be copied from the
Seam distribution into the example program directory. e.g.

copy <seam_home>/lib <examples_home>/ch6/RichFacesDemo/
copy <seam_home>/bootstrap <examples_home>/ch6/RichFaces/

All of the SeamGen generated applications are marked with an asterisk (*) 
below.

After building and deploying the examples, the following URLs are used to 
run the examples.

Chapter 1
=========
No Sample Applications

Chapter 2
=========
Seam Calculator – http://localhost:8080/SeamCalculator
Validating Seam Calculator – http://localhost:8080/SeamCalculator

Chapter 3
=========
Vacation Planner – http://localhost:8080/VacationPlanner

Chapter 4
=========
Seam Calculator Facelets – http://localhost:8080/SeamCalculator

Chapter 5
=========
Vacation Planner(*) – http://localhost:8080/vacationplanner

Chapter 6
=========
Rich Faces Demo(*) – http://localhost:8080/RichFacesDemo

Chapter 7
=========
Data(*) – http://localhost:8080/Data

Chapter 8
=========
Conversation(*) – http://localhost:8080/conversation

Chapter 9
=========
Hello World(*) – http://localhost:8080/HelloWorld

Chapter 10
=========
Seam Security(*) – http://localhost:8080/SeamSecurity
Seam Security Open ID(*) – http://localhost:8080/SeamSecurityOpenID

Chapter 11
=========
Enterprise(*) – http://localhost:8080/enterprise
Validating Seam Calculator – http://localhost:8080/SeamCalculator

